This folder contains the integral polynomial of SIMON32.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation14R_in31_out18' represents 
the integral polynomial of 14-round SIMON32 when we set the initial division property to in31 
and set the output division property to out18. 
We can get the integral polynomial p corresponding to  the initial division property in31 
by summing up all the monomials in the file.