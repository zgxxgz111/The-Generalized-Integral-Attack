This folder contains the integral polynomial of KATAN32.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(102R,0)' represents 
the integral polynomial of 102-round KATAN32. We can get the integral polynomial p 
 corresponding to  the initial division property in31 by summing up all the monomials in the file.