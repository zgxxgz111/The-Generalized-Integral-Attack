This folder contains the integral polynomial of KTANTAN32.
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(103R,0)' represents 
the integral polynomial of 103-round KTANTAN32. We can get the integral polynomial p 
 corresponding to  the initial division property in31 by summing up all the monomials in the file.
'key.txt' represents how to use the subkey bits in every round for KTANTAN32. 