This folder contains the integral polynomial of KTANTAN64
Let's illustrate the meaning of each file's name.
For example, 'StartDivisionPropertyInformation(74R,0)' represents 
the integral polynomial of 74-round KTANTAN64. We can get the integral polynomial p 
 corresponding to  the initial division property in63 by summing up all the monomials in the file.
'key.txt' represents how to use the subkey bits in every round. 